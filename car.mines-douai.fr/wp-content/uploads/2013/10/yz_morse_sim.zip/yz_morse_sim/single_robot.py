from morse.builder import *

# New instance of the robot
pioneer3dx = Pioneer3DX()
pioneer3dx.add_default_interface('ros')

# Pose sensor
pose = Pose()
pose.translate(z=0.8)
pioneer3dx.append(pose)

# Odometry Sensor
odometry = Odometry()
odometry.add_interface('ros', topic='/odom')
pioneer3dx.append(odometry)

# Laser Scanner Sensor
sick = Sick()
sick.translate(z=0.252)
sick.properties(Visible_arc = True)
sick.properties(laser_range = 10.0)
sick.properties(resolution = 1.0)
sick.properties(scan_window = 180.0)
sick.add_interface('ros', topic='/base_scan')
pioneer3dx.append(sick)

# Motion Actuator
motion = MotionVWDiff()
motion.add_interface('ros', topic='/cmd_vel')
pioneer3dx.append(motion)

# Keyboard Actuator
keyboard = Keyboard()
keyboard.properties(ControlType='Differential')
pioneer3dx.append(keyboard)

# Environment Description
env = Environment('laas/grande_salle')
env.place_camera([20, -10, 15])
env.aim_camera([1.0470, 0, 0.7854])
